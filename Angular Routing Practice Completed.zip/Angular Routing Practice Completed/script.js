var app = angular.module("myApp", ["ngRoute"]);
app.config(['$routeProvider','$locationProvider',function ($routeProvider, $locationProvider) {
    $locationProvider.hashPrefix('');
    $routeProvider
        .when("/Home", {
            templateUrl: "pages/home.html",
            controller: "home"
        })
        .when("/Products", {
            templateUrl: "pages/addProduct.html",
            controller: "addProduct"
        })
        .when("/Categories", {
            templateUrl: "pages/categories.html",
            controller: "Categories"
        }).otherwise({
            redirectTo: '/'
        });
}]);
app.controller("addProduct", function ($scope) {
    $scope.productList = [{
        power: false,
        productName: 'Soap',
        productQuantity: 5,
        productPrice: 10
    }];

    $scope.addNew = function () {
        $scope.productList.push({
            power: false,
            productName: $scope.productName,
            productQuantity: $scope.productQuantity,
            productPrice: $scope.productPrice
        });
        $scope.productName = "";
        $scope.productQuantity = "";
        $scope.productPrice = "";
    };

    $scope.removeProduct = function () {
        var oldList = $scope.productList;
        $scope.productList = [];
        angular.forEach(oldList, function (x) {
            if (!x.power) $scope.productList.push(x);
        });
    };

});

app.controller("home", function ($scope) {
    $scope.message = "THE CITY GENERAL STORE";
});

app.controller("Categories", function ($scope) {
    $scope.categories = ["Packaged Food Items", "Fruits",   "Vegetables","Dairy Products", "Plasticware","Staples","Freezed Products"];
});
